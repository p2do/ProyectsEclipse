package clases;


public class Cilindro {

	public double radio;
	public double altura;
	static final double PI= 3.14;
	
	/**
	 * Crea un cilindro con el radio y la altura especificados en metros
	 * @param radio
	 * @param altura
	 */
	public Cilindro(double radio, double altura) {
		this.radio=radio;
		this.altura=radio;
	}
	/**
	 * Crea un cilindro con el radio y la altura en un metro
	 */
	public Cilindro() {
		this.altura=1;
		this.radio=1;
	}
	/**
	 * Calcula la superficie de un cilindro
	 * 
	 * 
	 * @return la superficie de un cilindro en metros cuadrados
	 */
	public double superficie() {
		double superficie;
		superficie=2*PI*(this.radio*this.radio)+2*PI*this.radio*this.altura;
		return (double)Math.round(superficie * 100)/100;
	}
	/**
	 * Calcula el volumen de un cilindro
	 * 
	 * 
	 * @return el volumen de un cilindro en metros cubicos
	 */
	public double volumen() {
		double volumen= (PI*this.radio*this.radio)*this.altura;
		return (double)Math.round(volumen*100)/100;
	}
}
