package clases;


public class Cubo {
	public int lado;
	
	/**
	 * Crea un cubo con el lado especificado en metros
	 * @param lado
	 */
	public Cubo(int lado) {
		
		this.lado=lado;
		
	}
	
	/**
	 * Crea un cubo con el lado especificado en 1 metros
	 */
	public Cubo() {
		
		this.lado=1;
	}
	
	/**
	 * Calcula la superficie de un cubo
	 * 
	 * 
	 * @return la superficie de un cubo en metros cuadrados
	 */
	public double superficie() {
		return(this.lado*this.lado)*6;
	}
	
	/**
	 * Calcula el volumen de un cubo
	 * 
	 * 
	 * @return el volumen de un cubo en metros cubicos
	 */
	public double volumen() {
		
		return this.lado*this.lado*this.lado;
		
	}
}
