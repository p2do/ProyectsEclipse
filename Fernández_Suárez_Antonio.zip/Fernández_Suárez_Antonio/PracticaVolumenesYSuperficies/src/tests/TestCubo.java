package tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import clases.Cubo;

class TestCubo {

	@Test
	void testSuperficie() {
		
	Cubo c= new Cubo(2);
	double SuperficieObtenida=c.superficie();
	double SuperficieEsperada=24;
	
	assertEquals(SuperficieEsperada, SuperficieObtenida);
	
	}

	@Test
	void testVolumen() {
		
		Cubo c= new Cubo(2);
		double VolumenObtenida=c.volumen();
		double VolumenEsperada=8;
		
		assertEquals(VolumenEsperada, VolumenObtenida);
		
	}

}
