package tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import clases.Cilindro;

class TestCilindro {

	
	@Test
	void testSuperficie() {
		Cilindro c= new Cilindro(2,2);
		double SuperficieObtenida=c.superficie();
		double SuperficieEsperada=50.24;
		
		assertEquals(SuperficieEsperada, SuperficieObtenida);
	}

	
	@Test
	void testVolumen() {
		Cilindro c= new Cilindro(2,2);
		double VolumenObtenida=c.volumen();
		double VolumenEsperada=25.12;
		
		assertEquals(VolumenEsperada, VolumenObtenida);
	}
	

}
