package tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import clases.Maximos;
import clases.Minimos;

class TestMaximos {

	@Test
	void testMaximoDe2EnterosPositivos() {
		Maximos Max= new Maximos();
		int MaximoObtenida=Max.MaximoDe2EnterosPositivos(10,20);
		int MaximoEsperada=20;
		
		assertEquals(MaximoEsperada, MaximoObtenida);
	}

	@Test
	void testMaximoDe3EnterosPositivos() {
		Maximos Max= new Maximos();
		int MaximoObtenida=Max.MaximoDe3EnterosPositivos(10,20,30);
		int MaximoEsperada=30;
		
		assertEquals(MaximoEsperada, MaximoObtenida);
	}

}
