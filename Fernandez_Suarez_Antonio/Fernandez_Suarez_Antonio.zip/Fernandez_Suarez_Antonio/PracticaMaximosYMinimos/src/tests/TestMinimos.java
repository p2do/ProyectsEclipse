package tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import clases.Maximos;
import clases.Minimos;

class TestMinimos {

	@Test
	void testMinimoDe2EnterosPositivos() {
		
		Minimos Min= new Minimos();
		int MinimoObtenida=Min.MinimoDe2EnterosPositivos(10,20);
		int MinimoEsperada=10;
		
		assertEquals(MinimoEsperada, MinimoObtenida);
	}

	@Test
	void testMinimoDe3EnterosPositivos() {
		
		Minimos Min= new Minimos();
		int MinimoObtenida=Min.MinimoDe3EnterosPositivos(10,20,30);
		int MinimoEsperada=10;
		
		assertEquals(MinimoEsperada, MinimoObtenida);
	}

}
