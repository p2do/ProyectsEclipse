package clases;

public class Minimos {

	/**
	 * 
	 * Calcula el minimo entre dos numeros enteros positivos pasados por parametro
	 * 
	 * @param valor1
	 * @param valor2
	 * @return el minimo entre dos numeros enteros positivos
	 */
	public static int MinimoDe2EnterosPositivos(int valor1, int valor2) {
		if (valor1>=0 && valor2>=0) {
			
				if (valor1<valor2) {
					return valor1;
				} else if (valor1>valor2) {
					return valor2;
				} else {
					return valor1;
				}
			}else {
				return 0;
			}
		}
	
	/**
	 * 
	 * Calcula el minimo entre tres numeros enteros positivos pasados por parametro
	 * 
	 * @param valor1
	 * @param valor2
	 * @param valor3
	 * @return el minimo entre tres numeros enteros positivos
	 */
	public static int MinimoDe3EnterosPositivos(int valor1, int valor2, int valor3) {	
		if (valor1>=0 && valor2>=0 && valor3>=0) {
			
			if (valor1<valor2 && valor1<valor3) {
				return valor1;
			}else if (valor2<valor1 && valor2<valor3) {
				return valor2;
			}else{
				return valor3;
			}	
		} else {
			return 0;
		}
	}

}
