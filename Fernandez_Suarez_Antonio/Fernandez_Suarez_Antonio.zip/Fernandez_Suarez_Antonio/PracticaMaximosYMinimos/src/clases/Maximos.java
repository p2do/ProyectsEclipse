package clases;

public class Maximos {

	/**
	 * 
	 * Calcula el maximo entre dos numeros enteros positivos pasados por parametro
	 * 
	 * @param valor1
	 * @param valor2
	 * @return	el maximo entre dos numeros enteros positivos
	 */
	public static int MaximoDe2EnterosPositivos(int valor1, int valor2) {
		if (valor1>=0 && valor2>=0) {
			
				if (valor1>valor2) {
					return valor1;
				} else if (valor1<valor2) {
					return valor2;
				} else {
					return valor1;
				}
			}else {
				return 0;
			}
		}
	
	/**
	 * 
	 * Calcula el maximo entre tres numeros enteros positivos pasados por parametro
	 * 
	 * @param valor1
	 * @param valor2
	 * @param valor3
	 * @return el maximo entre tres numeros enteros positivos
	 */
	public static int MaximoDe3EnterosPositivos(int valor1, int valor2, int valor3) {	
		if (valor1>=0 && valor2>=0 && valor3>=0) {
			
			if (valor1>valor2 && valor1>valor3) {
				return valor1;
			}else if (valor2>valor1 && valor2>valor3) {
				return valor2;
			}else{
				return valor3;
			}	
		} else {
			return 0;
		}
	}
}
